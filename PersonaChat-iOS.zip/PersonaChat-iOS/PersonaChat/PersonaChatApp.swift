import SwiftUI

@main
struct PersonaChatApp: App {
    init() { CharacterStore.shared.load() }
    var body: some Scene {
        WindowGroup {
            TabView {
                NavigationStack { CharactersView() }
                    .tabItem { Label("Characters", systemImage: "person.2") }
                NavigationStack { ModelsView() }
                    .tabItem { Label("Model", systemImage: "cpu") }
            }
        }
    }
}
