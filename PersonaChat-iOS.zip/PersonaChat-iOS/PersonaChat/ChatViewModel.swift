import Foundation
import Combine

@MainActor
final class ChatViewModel: ObservableObject {
    let character: Character
    @Published var messages: [ChatMessage] = []
    @Published var streaming: String = ""
    @Published var generating = false
    var temperature: Float = 0.8

    private let store = CharacterStore.shared
    private var genTask: Task<Void, Never>?

    init(character: Character) {
        self.character = character
        messages = store.loadMessages(character.id)
        if messages.isEmpty, !character.greeting.isEmpty {
            messages = [ChatMessage(role: "assistant", content: character.greeting)]
            persist()
        }
    }

    func send(_ text: String) {
        guard !generating, !text.isEmpty, LLMEngine.shared.isLoaded else { return }
        messages.append(ChatMessage(role: "user", content: text))
        persist()
        let prompt = PromptBuilder.buildPrompt(c: character,
                                               history: PromptBuilder.trimmed(messages))
        generating = true
        streaming = ""
        genTask = Task.detached(priority: .userInitiated) { [weak self] in
            var acc = ""
            LLMEngine.shared.generate(prompt: prompt, temp: 0.8, nPredict: 600) { piece in
                acc += piece
                let snapshot = acc
                Task { @MainActor in self?.streaming = snapshot }
            }
            let reply = acc.trimmingCharacters(in: .whitespacesAndNewlines)
            Task { @MainActor in
                guard let self else { return }
                self.streaming = ""
                self.generating = false
                if !reply.isEmpty {
                    self.messages.append(ChatMessage(role: "assistant", content: reply))
                    self.persist()
                }
            }
        }
    }

    func stop() { LLMEngine.shared.stop() }

    func clearChat() {
        stop(); genTask?.cancel()
        messages = []; streaming = ""; generating = false
        persist()
    }

    private func persist() { store.saveMessages(character.id, messages) }
}
