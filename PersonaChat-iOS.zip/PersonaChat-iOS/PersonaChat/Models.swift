import Foundation

struct Character: Codable, Identifiable, Equatable {
    var id: UUID = UUID()
    var name: String = "New Character"
    var avatar: String = "\u{1F9D9}"
    var persona: String = ""
    var scenario: String = ""
    var greeting: String = ""
    var exampleDialogue: String = ""
    var createdAt: Date = Date()
}

struct ChatMessage: Codable, Equatable, Identifiable {
    var id: UUID = UUID()
    var role: String   // "system" | "user" | "assistant"
    var content: String
    var ts: Date = Date()
}

enum StorePaths {
    static var docs: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    static func chatFile(_ id: UUID) -> URL { docs.appendingPathComponent("chat_\(id.uuidString).json") }
    static var charactersFile: URL { docs.appendingPathComponent("characters.json") }
    static func ggufs() -> [URL] {
        (try? FileManager.default.contentsOfDirectory(at: docs, includingPropertiesForKeys: nil))
            ?.filter { $0.pathExtension == "gguf" }.sorted { $0.lastPathComponent < $1.lastPathComponent } ?? []
    }
}
