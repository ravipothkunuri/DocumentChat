# PersonaChat — offline character chat (llama.cpp on Android)

A complete Android chat app that runs LLMs **fully on-device** via llama.cpp (JNI):
create characters, chat with them with streaming replies, and rewrite any character
card with a plain-English prompt processed by the local model. No accounts, no cloud,
no network calls for inference — the app adds no filtering layer; behavior is whatever
the GGUF model you load produces.

## Features
- **Model screen**: list `.gguf` files in the private files dir, download a GGUF from a URL with progress, load/unload, context-size slider.
- **Characters**: name, emoji avatar, persona, scenario, greeting, example dialogue; JSON persistence per character.
- **Chat**: streaming token output, stop/clear, uses the model's built-in chat template (`llama_chat_apply_template`) with a plain-format fallback.
- **AI Modify**: meta-prompt asks the local model to rewrite the card inside `<<<JSON>>>...<<<END>>>` markers; parsed and previewed before applying.
- JNI bridge (`llama-android.cpp`) uses the modern C API: `llama_model_load_from_file`, sampler chains, flash attention, naive context shift.

## Build
1. Install Android Studio (Hedgehog+), Android SDK 34, NDK (Side by Side) and CMake 3.22.1 from the SDK Manager.
2. Clone/fetch llama.cpp sources:
   ```bash
   ./scripts/fetch_llama_cpp.sh        # or: git clone https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp
   ```
3. Open the project in Android Studio, let Gradle sync (wrapper jar will be generated; CLI: `gradle wrapper` first).
4. Build & run on an ARM64 device/emulator (x86_64 works but is slow).
5. Get a GGUF model — three ways, pick one (details below):
   - **In-app download** (easiest): paste a direct URL on the Models screen, tap Download.
   - **Download on PC, push via adb** (faster/reliable for big files).
   - **Download on the phone** with a browser/HF app and copy into the files dir.

## Getting a GGUF model

Models must be single-file `.gguf` (instruct/chat fine-tunes work best — the app uses the
model's built-in chat template when present). On a phone, stay small: **1–4B params**,
quant **Q4_K_M** by default (drop to Q3_K_M / IQ4_XS on low-RAM devices; Q6_K/Q8_0 if you
have 8GB+ RAM). Rule of thumb: model file size + ~1GB for context overhead must fit in RAM.

### Option A — in-app downloader
1. Find a GGUF on Hugging Face (search a model + "GGUF"; `bartowski` and `unsloth` repos are
   reliable quantizations).
2. Open the file's page → click the download arrow → **copy the direct link** (a
   `.../resolve/main/<file>.gguf` URL).
3. Paste it into "GGUF download URL" on the app's Models screen → Download. The file lands
   directly in the app's private files dir and appears in the list → tap **Load**.

Example direct URL (Qwen3 1.7B, ~1.3GB — good first test):
```
https://huggingface.co/bartowski/Qwen_Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q4_K_M.gguf
```
Note: these URLs redirect; the app's downloader follows redirects, but the *first* hop must
be the file. If a download fails, use Option B.

### Option B — PC download + adb (recommended for files >2GB)
```bash
# on your PC (or: click the file on huggingface.co and download via browser)
huggingface-cli download bartowski/Qwen_Qwen3-1.7B-GGUF \
  --include "Qwen3-1.7B-Q4_K_M.gguf" --local-dir .

# push to the device, then move it into the app's private files dir
# (works with the debug build; 'run-as' requires the app to be debuggable)
adb push Qwen3-1.7B-Q4_K_M.gguf /data/local/tmp/
adb shell run-as com.personachat cp /data/local/tmp/Qwen3-1.7B-Q4_K_M.gguf files/
```
Then open the app → Models → **Rescan** → Load.

### Option C — on-device download
Download the `.gguf` in the phone's browser (Files/Downloads), then either use the app's
downloader instead, or with a rooted device copy it to
`/data/data/com.personachat/files/`. Without root, Option A is the equivalent path —
browsers can't write into another app's private dir.

### Verifying the file
The Models screen shows file size — compare it with the size listed on the Hugging Face page.
A truncated download will fail at load time with `failed to load model` in logcat
(`adb logcat -s persona-jni`); just re-download. Also avoid *split* GGUFs
(`...-00001-of-00002.gguf`) — the app loads single files only.

## Notes / caveats
- CPU-only by default (`n_gpu_layers = 0`); wire up Vulkan/OpenCL in llama.cpp's CMake if you want GPU offload.
- First token latency and speed depend entirely on the model size and device RAM. 4096 ctx ≈ a few hundred MB extra for KV on small models.
- llama.cpp renames C API symbols occasionally. If NDK build fails on a missing symbol, open the checked-out `llama.h` and adjust `llama-android.cpp` (single place).
- History is trimmed to ~6k chars before prompting; the JNI side truncates/shifts if the context fills mid-generation.
- "No restrictions" here means: offline, private, no server-side anything. The app doesn't censor prompts, but it also doesn't include a safety-bypass/jailbreak module — what a given model will or won't generate depends on the model file you load.
