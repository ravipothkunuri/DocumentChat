import Foundation
import llama

/// Single-model engine wrapping the llama.cpp C API. CPU-only by default.
/// `generate` blocks — call it from a background thread/queue.
final class LLMEngine: @unchecked Sendable {
    static let shared = LLMEngine()

    private var model: OpaquePointer?
    private var ctx: OpaquePointer?
    private var vocab: OpaquePointer?
    private(set) var nCtx: Int32 = 4096
    private let lock = NSLock()
    private var stopFlag = false

    private(set) var isLoaded = false

    func loadModel(path: String, nCtx: Int32 = 4096, nThreads: Int32 = 4) -> Bool {
        lock.lock(); defer { lock.unlock() }
        freeLocked()
        llama_backend_init()
        var mp = llama_model_default_params()
        mp.n_gpu_layers = 0 // raise only with a Metal-enabled build
        guard let m = llama_model_load_from_file(path, mp) else { return false }
        var cp = llama_context_default_params()
        cp.n_ctx = UInt32(nCtx)
        cp.n_threads = UInt32(nThreads)
        cp.n_threads_batch = UInt32(nThreads)
        cp.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_ENABLED
        guard let c = llama_init_from_model(m, cp) else {
            llama_model_free(m); return false
        }
        model = m; ctx = c; vocab = llama_model_get_vocab(m)
        self.nCtx = nCtx; isLoaded = true
        return true
    }

    func unload() { lock.lock(); defer { lock.unlock() }; freeLocked() }

    func stop() { stopFlag = true }

    private func freeLocked() {
        if let c = ctx { llama_free(c); ctx = nil }
        if let m = model { llama_model_free(m); model = nil }
        vocab = nil; isLoaded = false
    }

    /// Model's built-in chat template via metadata; "" means caller should fall back.
    func applyChatTemplate(_ messages: [(role: String, content: String)], addAssistant: Bool) -> String {
        lock.lock(); defer { lock.unlock() }
        guard let model else { return "" }
        var tmpl = [CChar](repeating: 0, count: 8192)
        let nTmpl = llama_model_meta_val_str(model, "tokenizer.chat_template", &tmpl, Int32(tmpl.count))
        guard nTmpl > 0 else { return "" }

        let rolePtrs = messages.map { strdup($0.role) }
        let contentPtrs = messages.map { strdup($0.content) }
        defer { rolePtrs.forEach { free($0) }; contentPtrs.forEach { free($0) } }
        var chat = (0..<messages.count).map {
            llama_chat_message(role: rolePtrs[$0], content: contentPtrs[$0])
        }
        let needed = tmpl.withUnsafeBufferPointer { bp in
            chat.withUnsafeMutableBufferPointer { cp in
                llama_chat_apply_template(bp.baseAddress, cp.baseAddress, cp.count, addAssistant, nil, 0)
            }
        }
        guard needed > 0 else { return "" }
        var buf = [CChar](repeating: 0, count: Int(needed) + 8)
        tmpl.withUnsafeBufferPointer { bp in
            chat.withUnsafeMutableBufferPointer { cp in
                _ = llama_chat_apply_template(bp.baseAddress, cp.baseAddress, cp.count, addAssistant, &buf, Int32(buf.count))
            }
        }
        return String(cString: buf)
    }

    /// Token-streaming generation. Blocks the caller's thread.
    @discardableResult
    func generate(prompt: String, temp: Float = 0.8, topP: Float = 0.95,
                  nPredict: Int32 = 512, seed: UInt32? = nil,
                  onToken: (String) -> Void) -> String {
        lock.lock(); defer { lock.unlock() }
        guard let ctx, let vocab else { return "" }
        stopFlag = false

        let nMax = Int(nCtx) - 8
        var tokens = [llama_token](repeating: 0, count: nMax + 8)
        var nPrompt = llama_tokenize(vocab, prompt, Int32(prompt.utf8.count),
                                     &tokens, Int32(tokens.count), true, true)
        guard nPrompt > 0 else { return "" }
        if nPrompt > nMax { tokens.removeFirst(nPrompt - nMax); nPrompt = Int32(nMax) }

        let tokPtr = UnsafeMutablePointer<llama_token>.allocate(capacity: tokens.count)
        tokPtr.initialize(from: tokens, count: tokens.count)
        defer { tokPtr.deallocate() }

        var batch = llama_batch_get_one(tokPtr, nPrompt)
        guard llama_decode(ctx, batch) == 0 else { return "" }

        let sp = llama_sampler_chain_init(llama_sampler_chain_default_params())
        llama_sampler_chain_add(sp, llama_sampler_init_top_p(topP, 1))
        llama_sampler_chain_add(sp, llama_sampler_init_temp(temp <= 0 ? 0.05 : temp))
        llama_sampler_chain_add(sp, llama_sampler_init_dist(seed ?? UInt32.random(in: 0...UInt32.max)))
        defer { llama_sampler_free(sp) }

        var out = ""
        let nKeep: Int32 = 256
        var i: Int32 = 0
        while i < nPredict && !stopFlag {
            let tok = llama_sampler_sample(sp, ctx, -1)
            if llama_vocab_is_eog(vocab, tok) { break }
            var piece = [CChar](repeating: 0, count: 256)
            let n = llama_token_to_piece(vocab, tok, &piece, Int32(piece.count), false, true)
            if n > 0 {
                let s = String(cString: piece)
                out += s
                onToken(s)
            }
            tokPtr.pointee = tok
            batch = llama_batch_get_one(tokPtr, 1)
            if llama_decode(ctx, batch) != 0 { break }
            if llama_get_kv_cache_used_cells(ctx) >= nCtx - 4 {
                llama_kv_cache_seq_rm(ctx, 0, 1, nKeep)
                llama_kv_cache_seq_add(ctx, 0, nKeep, -1, -1)
            }
            i += 1
        }
        return out
    }
}
