import SwiftUI

struct ModelsView: View {
    @State private var models: [URL] = ModelFiles.list()
    @State private var status = ""
    @State private var urlText = ""
    @State private var progress: Double?
    @State private var ctxSize: Double = 4096
    @State private var busy = false
    @ObservedObject private var engineBox = EngineBox()

    // Hugging Face browser
    @State private var query = ""
    @State private var repos: [HFApi.Repo] = []
    @State private var selectedRepo: String?
    @State private var files: [(path: String, size: Int64, url: URL)] = []
    @State private var searching = false

    var body: some View {
        Form {
            Section("Download") {
                TextField("GGUF download URL (.../resolve/main/file.gguf)", text: $urlText)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                HStack {
                    Button("Download") { startDownload() }.disabled(busy || urlText.isEmpty)
                    if let p = progress { ProgressView(value: p).frame(width: 80) }
                }
                Text(status).font(.caption).foregroundStyle(.secondary)
            }
            Section("Browse Hugging Face (GGUF)") {
                HStack {
                    TextField("Search models, e.g. qwen3, llama-3.2", text: $query)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    Button(searching ? "..." : "Search") { search() }
                        .disabled(searching || query.isEmpty)
                }
                ForEach(repos) { r in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text(r.displayName).font(.headline)
                            Spacer()
                            Text("\((r.downloads ?? 0).formatted()) dl · \(r.likes ?? 0) likes")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        .contentShape(Rectangle())
                        .onTapGesture { pick(r) }
                        if selectedRepo == r.id {
                            ForEach(files, id: \.path) { f in
                                HStack {
                                    VStack(alignment: .leading) {
                                        Text(f.path.components(separatedBy: "/").last ?? f.path)
                                            .font(.caption).lineLimit(1)
                                        Text(String(format: "%.2f GB", Double(f.size) / 1e9))
                                            .font(.caption2).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Button("Get") { downloadFile(f.url) }
                                        .disabled(progress != nil)
                                }
                            }
                        }
                    }
                }
            }
            Section("Context: \(Int(ctxSize)) tokens") {
                Slider(value: $ctxSize, in: 2048...16384, step: 2048)
            }
            Section("On-device models (Documents)") {
                ForEach(models, id: \.self) { f in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(f.lastPathComponent)
                            Text(String(format: "%.1f MB", Double(fileSize(f)) / 1e6))
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        if LLMEngine.shared.isLoaded {
                            Button("Unload") { LLMEngine.shared.unload(); engineBox.tick() }
                                .buttonStyle(.bordered)
                        } else {
                            Button("Load") { load(f) }.buttonStyle(.borderedProminent).disabled(busy)
                        }
                    }
                }
                Button("Rescan") { models = ModelFiles.list() }
            }
            if LLMEngine.shared.isLoaded {
                Label("Model loaded", systemImage: "checkmark.circle").foregroundStyle(.green)
            }
        }
        .navigationTitle("Local model")
    }

    private func fileSize(_ u: URL) -> UInt64 {
        let attrs = try? FileManager.default.attributesOfItem(atPath: u.path)
        return (attrs?[.size] as? UInt64) ?? 0
    }

    private func search() {
        searching = true
        Task {
            do { repos = try await HFApi.search(query) }
            catch { repos = []; status = "Search failed: \(error.localizedDescription)" }
            searching = false
        }
    }

    private func pick(_ r: HFApi.Repo) {
        selectedRepo = r.id
        Task {
            do { files = try await HFApi.ggufFiles(r.id) }
            catch { files = []; status = "Failed to list files" }
        }
    }

    private func downloadFile(_ url: URL) {
        busy = true
        let dest = ModelFiles.newDownloadURL(for: url)
        Task {
            do {
                try await DownloadManager.download(url: url, dest: dest) { done, total in
                    Task { @MainActor in
                        status = String(format: "Downloading %.1f MB", Double(done) / 1e6)
                        progress = (total != nil && total! > 0) ? Double(done) / Double(total!) : nil
                    }
                }
                status = "Saved \(dest.lastPathComponent)"; progress = nil; busy = false
                models = ModelFiles.list()
            } catch {
                status = "Download failed: \(error.localizedDescription)"; progress = nil; busy = false
            }
        }
    }

    private func load(_ f: URL) {
        busy = true; status = "Loading \(f.lastPathComponent)..."
        let nCtx = Int32(ctxSize)
        DispatchQueue.global().async {
            let ok = LLMEngine.shared.loadModel(path: f.path, nCtx: nCtx)
            DispatchQueue.main.async {
                busy = false
                status = ok ? "Loaded \(f.lastPathComponent)" : "Failed to load"
                engineBox.tick()
            }
        }
    }

    private func startDownload() {
        guard let url = URL(string: urlText) else { status = "Bad URL"; return }
        busy = true
        let dest = ModelFiles.newDownloadURL(for: url)
        Task {
            do {
                try await DownloadManager.download(url: url, dest: dest) { done, total in
                    Task { @MainActor in
                        status = String(format: "Downloading %.1f MB", Double(done) / 1e6)
                        progress = (total != nil && total! > 0) ? Double(done) / Double(total!) : nil
                    }
                }
                status = "Saved \(dest.lastPathComponent)"; progress = nil; busy = false
                models = ModelFiles.list()
            } catch {
                status = "Download failed: \(error.localizedDescription)"
                progress = nil; busy = false
            }
        }
    }
}

/// Tiny observable to poke SwiftUI after engine state changes.
final class EngineBox: ObservableObject { @Published var n = 0; func tick() { n += 1 } }
