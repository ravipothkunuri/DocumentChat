package com.personachat.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.personachat.ai.CharacterModifier
import com.personachat.ai.LlmEngine
import com.personachat.data.Repositories
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiModifyScreen(charId: String, onBack: () -> Unit) {
    val c = remember(charId) { Repositories.byId(charId) } ?: return LaunchedEffect(Unit) { onBack() }
    val scope = rememberCoroutineScope()

    var instruction by remember { mutableStateOf("") }
    var raw by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    Scaffold(topBar = {
        TopAppBar(title = { Text("AI modify: ${c.name}") },
            navigationIcon = { TextButton(onBack) { Text("Back") } })
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState())
            .fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {

            Text("Describe the change in plain words, e.g. \"make her a cynical pirate captain\" or \"move the scene to a space station\".",
                style = MaterialTheme.typography.bodyMedium)

            OutlinedTextField(instruction, { instruction = it },
                label = { Text("Modification prompt") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp), maxLines = 8)

            Button(
                enabled = !busy && instruction.isNotBlank() && LlmEngine.isLoaded,
                onClick = {
                    scope.launch {
                        busy = true; error = null; result = null; raw = ""
                        val updated = withContext(Dispatchers.IO) {
                            runCatching { CharacterModifier.runBlocking(c, instruction) { raw = it } }
                        }
                        busy = false
                        updated.exceptionOrNull()?.let { error = it.message }
                        val u = updated.getOrNull()
                        if (u == null && error == null) error = "Could not parse the model output — try again or rephrase."
                        result = u?.let { "Name: ${it.name}\n\nPersona: ${it.persona}\n\nScenario: ${it.scenario}\n\nGreeting: ${it.greeting}" }
                        if (u != null) {
                            // stage into repo only on Apply
                            pendingUpdate = u
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (busy) "Thinking..." else "Generate changes") }

            if (!LlmEngine.isLoaded)
                Text("Load a model first (Models screen).", color = MaterialTheme.colorScheme.error)

            if (raw.isNotBlank()) {
                Text("Raw output", style = MaterialTheme.typography.labelLarge)
                Text(raw, style = MaterialTheme.typography.bodySmall)
            }
            result?.let {
                HorizontalDivider()
                Text("Proposed changes", style = MaterialTheme.typography.titleMedium)
                Text(it)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        pendingUpdate?.let { u -> Repositories.upsert(u); pendingUpdate = null; onBack() }
                    }) { Text("Apply & save") }
                    OutlinedButton(onClick = { pendingUpdate = null; result = null }) { Text("Discard") }
                }
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}

private var pendingUpdate: com.personachat.data.Character? = null
