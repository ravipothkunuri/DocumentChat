package com.personachat.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import java.io.File

/**
 * Single-model, single-session engine wrapping llama.cpp through JNI.
 * Everything runs on-device; no network is used for inference.
 */
object LlmEngine {

    interface TokenCallback { fun onToken(piece: String) }

    @Volatile
    var isLoaded: Boolean = false
        private set

    init { System.loadLibrary("persona-jni") }

    private external fun nativeLoadModel(path: String, nCtx: Int, nThreads: Int): Boolean
    private external fun nativeFree()
    private external fun nativeStop()
    private external fun nativeGenerate(
        prompt: String, temp: Float, topP: Float, nPredict: Int, seed: Long,
        callback: TokenCallback
    ): String
    private external fun nativeApplyTemplate(
        roles: Array<String>, contents: Array<String>, addAssistant: Boolean
    ): String

    fun loadModel(file: File, nCtx: Int = 4096, nThreads: Int = 4): Boolean {
        val ok = nativeLoadModel(file.absolutePath, nCtx, nThreads)
        isLoaded = ok
        return ok
    }

    fun unload() { nativeFree(); isLoaded = false }
    fun stop() = nativeStop()

    /** Applies the model's built-in chat template; empty string means "no template". */
    fun applyChatTemplate(messages: List<Pair<String, String>>, addAssistant: Boolean = true): String {
        if (messages.isEmpty()) return ""
        return try {
            nativeApplyTemplate(
                messages.map { it.first }.toTypedArray(),
                messages.map { it.second }.toTypedArray(),
                addAssistant
            )
        } catch (t: Throwable) { "" }
    }

    /** Blocking call -- collect on a background dispatcher. */
    fun generateBlocking(
        prompt: String, temp: Float = 0.8f, topP: Float = 0.95f,
        nPredict: Int = 512, seed: Long = -1, onToken: (String) -> Unit
    ): String {
        val cb = object : TokenCallback { override fun onToken(piece: String) = onToken(piece) }
        return nativeGenerate(prompt, temp, topP, nPredict, seed, cb)
    }

    fun generateStream(
        prompt: String, temp: Float = 0.8f, topP: Float = 0.95f,
        nPredict: Int = 512, seed: Long = -1
    ): Flow<String> = callbackFlow {
        val cb = object : TokenCallback {
            override fun onToken(piece: String) { trySend(piece) }
        }
        try {
            nativeGenerate(prompt, temp, topP, nPredict, seed, cb)
        } catch (t: Throwable) {
            trySend("\n[generation error: ${t.message}]\n")
        }
        close()
        awaitClose { }
    }.flowOn(Dispatchers.IO)
}
