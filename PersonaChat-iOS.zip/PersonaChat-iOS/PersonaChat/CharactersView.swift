import SwiftUI

struct CharactersView: View {
    @ObservedObject var store = CharacterStore.shared
    @State private var showNew = false
    @State private var newId: UUID?

    var body: some View {
        List {
            ForEach(store.characters) { c in
                NavigationLink(value: c.id) {
                    HStack(spacing: 12) {
                        Text(c.avatar).font(.largeTitle)
                        VStack(alignment: .leading) {
                            Text(c.name).font(.headline)
                            Text(String(c.persona.prefix(90))).font(.caption).lineLimit(2)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .onDelete { idx in
                if let first = idx.first { store.delete(store.characters[first].id) }
            }
        }
        .navigationTitle("PersonaChat")
        .navigationDestination(for: UUID.self) { id in
            if let c = store.characters.first(where: { $0.id == id }) {
                ChatView(character: c)
            }
        }
        .background(
            NavigationLink(destination: editDestination, isActive: $showNew) { EmptyView() }
                .hidden()
        )
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button {
                    newId = store.newCharacter().id
                    showNew = true
                } label: { Image(systemName: "plus") }
            }
        }
    }

    @ViewBuilder private var editDestination: some View {
        if let id = newId, let c = store.characters.first(where: { $0.id == id }) {
            CharacterEditView(character: c)
        } else {
            Text("…")
        }
    }
}
