package com.personachat.data

import kotlinx.serialization.Serializable

@Serializable
data class Character(
    val id: String,
    var name: String,
    var avatar: String = "\uD83E\uDDD9", // emoji
    var persona: String = "",          // who the character is
    var scenario: String = "",         // setting / circumstances
    var greeting: String = "",         // first message the character sends
    var exampleDialogue: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
data class ChatMessage(
    val role: String, // "system" | "user" | "assistant"
    val content: String,
    val ts: Long = System.currentTimeMillis()
)
