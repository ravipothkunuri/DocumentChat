import Foundation
import Combine

final class CharacterStore: ObservableObject {
    static let shared = CharacterStore()
    @Published var characters: [Character] = []
    private let encoder: JSONEncoder = { let e = JSONEncoder(); e.outputFormatting = .prettyPrinted; return e }()

    func load() {
        guard let data = try? Data(contentsOf: StorePaths.charactersFile) else { return }
        characters = (try? JSONDecoder().decode([Character].self, from: data)) ?? []
    }
    private func persist() {
        guard let data = try? encoder.encode(characters) else { return }
        try? data.write(to: StorePaths.charactersFile)
    }
    @discardableResult
    func newCharacter() -> Character {
        let c = Character(); characters.append(c); persist(); return c
    }
    func upsert(_ c: Character) {
        if let i = characters.firstIndex(where: { $0.id == c.id }) { characters[i] = c }
        else { characters.append(c) }
        persist()
    }
    func delete(_ id: UUID) {
        characters.removeAll { $0.id == id }
        persist()
        try? FileManager.default.removeItem(at: StorePaths.chatFile(id))
    }

    func loadMessages(_ id: UUID) -> [ChatMessage] {
        guard let data = try? Data(contentsOf: StorePaths.chatFile(id)) else { return [] }
        return (try? JSONDecoder().decode([ChatMessage].self, from: data)) ?? []
    }
    func saveMessages(_ id: UUID, _ msgs: [ChatMessage]) {
        guard let data = try? encoder.encode(msgs) else { return }
        try? data.write(to: StorePaths.chatFile(id))
    }
}

enum ModelFiles {
    static func list() -> [URL] { StorePaths.ggufs() }
    static func newDownloadURL(for url: URL) -> URL {
        let name = url.lastPathComponent.isEmpty ? "model.gguf" : url.lastPathComponent
        return StorePaths.docs.appendingPathComponent(name)
    }
    static func excludeFromBackup(_ url: URL) {
        var u = url
        var v = URLResourceValues()
        v.isExcludedFromBackup = true
        try? u.setResourceValues(v)
    }
}
