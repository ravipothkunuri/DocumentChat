#!/usr/bin/env bash
# Run from the project root. Fetches llama.cpp into app/src/main/cpp/llama.cpp.
# llama.cpp changes its C API occasionally; this project was written against the
# post-b4xxx API (llama_model_load_from_file, llama_sampler_chain, llama_chat_apply_template).
# If a build error says a symbol is missing, check llama.h at the checked-out commit
# and rename in app/src/main/cpp/llama-android.cpp.
set -e
git clone --depth 1 https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp
echo "Done. If CMake config fails, try: git -C app/src/main/cpp/llama.cpp checkout <a release tag>"
