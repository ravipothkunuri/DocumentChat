package com.personachat.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.personachat.ai.Downloader
import com.personachat.ai.LlmEngine
import com.personachat.data.Repositories
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var models by remember { mutableStateOf(Repositories.listModels()) }
    var status by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var progress by remember { mutableStateOf<Float?>(null) }
    var ctxSize by remember { mutableStateOf(4096f) }

    fun refresh() { models = Repositories.listModels() }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Local model") },
            navigationIcon = { TextButton(onBack) { Text("Back") } })
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            Text("Place .gguf files in the app files dir, or download one.",
                style = MaterialTheme.typography.bodyMedium)

            OutlinedTextField(url, { url = it }, label = { Text("GGUF download URL") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = progress == null && url.isNotBlank(), onClick = {
                    scope.launch {
                        try {
                            status = "Downloading..."
                            val dest = Repositories.newDownloadFile(url)
                            Downloader.download(url, dest) { done, total ->
                                progress = if (total > 0) done.toFloat() / total else null
                                status = "Downloading %.1f MB".format(done / 1e6)
                            }
                            status = "Saved: ${dest.name}"
                            refresh()
                        } catch (t: Throwable) { status = "Download failed: ${t.message}" }
                        progress = null
                    }
                }) { Text("Download") }

                OutlinedButton(onClick = refresh) { Text("Rescan") }

                progress?.let { CircularProgressIndicator(progress = it) }
            }

            Text("Context size: ${ctxSize.toInt()} tokens",
                style = MaterialTheme.typography.labelLarge)
            Slider(ctxSize, { ctxSize = it }, valueRange = 2048f..16384f, steps = 6)

            HorizontalDivider()

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(models, key = { it.name }) { f ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text(f.name, style = MaterialTheme.typography.titleMedium)
                                Text("%.1f MB".format(f.length() / 1e6),
                                    style = MaterialTheme.typography.bodySmall)
                            }
                            if (LlmEngine.isLoaded) {
                                OutlinedButton(onClick = { LlmEngine.unload(); status = "Unloaded" }) {
                                    Text("Unload")
                                }
                            } else {
                                Button(onClick = {
                                    scope.launch {
                                        status = "Loading ${f.name}..."
                                        status = if (LlmEngine.loadModel(f, ctxSize.toInt()))
                                            "Loaded ${f.name}" else "Failed to load model"
                                    }
                                }) { Text("Load") }
                            }
                        }
                    }
                }
            }

            if (status.isNotBlank()) Text(status, style = MaterialTheme.typography.bodyMedium)
            if (LlmEngine.isLoaded)
                Text("Model loaded \u2713", color = MaterialTheme.colorScheme.primary)
        }
    }
}
