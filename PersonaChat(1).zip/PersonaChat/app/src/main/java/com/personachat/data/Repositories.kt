package com.personachat.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

object Repositories {

    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

    private lateinit var appCtx: Context
    private val charsFile by lazy { File(appCtx.filesDir, "characters.json") }

    private val _characters = MutableStateFlow<List<Character>>(emptyList())
    val characters: StateFlow<List<Character>> = _characters.asStateFlow()

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        _characters.value = loadChars()
    }

    private inline fun <reified T> load(file: File, default: T): T =
        runCatching { if (file.exists()) json.decodeFromString<T>(file.readText()) else default }
            .getOrDefault(default)

    private inline fun <reified T> save(file: File, value: T) {
        file.writeText(json.encodeToString(value))
    }

    private fun loadChars(): List<Character> = load(charsFile, emptyList())

    fun newCharacter(): Character {
        val c = Character(id = UUID.randomUUID().toString(), name = "New Character")
        upsert(c); return c
    }

    fun upsert(c: Character) {
        _characters.value = _characters.value.filterNot { it.id == c.id } + c
        save(charsFile, _characters.value)
    }

    fun delete(id: String) {
        _characters.value = _characters.value.filterNot { it.id == id }
        save(charsFile, _characters.value)
        chatFile(id).delete()
    }

    fun byId(id: String): Character? = _characters.value.find { it.id == id }

    // ---- chat history (one JSON file per character) ----

    private fun chatFile(id: String) = File(appCtx.filesDir, "chat_$id.json")

    fun loadMessages(id: String): List<ChatMessage> = load(chatFile(id), emptyList())

    fun saveMessages(id: String, msgs: List<ChatMessage>) = save(chatFile(id), msgs)

    // ---- local model files ----

    fun ggufDir(): File = appCtx.filesDir

    fun listModels(): List<File> =
        appCtx.filesDir.listFiles()?.filter { it.extension == "gguf" }?.sortedBy { it.name } ?: emptyList()

    fun newDownloadFile(url: String): File =
        File(appCtx.filesDir, url.substringAfterLast('/').ifBlank { "model.gguf" })
}
