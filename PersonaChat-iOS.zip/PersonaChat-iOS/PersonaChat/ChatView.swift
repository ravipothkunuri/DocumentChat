import SwiftUI

struct ChatView: View {
    @StateObject private var vm: ChatViewModel
    @State private var input = ""
    @Environment(\.dismiss) private var dismiss

    init(character: Character) {
        _vm = StateObject(wrappedValue: ChatViewModel(character: character))
    }

    var body: some View {
        VStack {
            if !LLMEngine.shared.isLoaded {
                Text("No model loaded — open the Model tab first.")
                    .foregroundStyle(.red).padding()
            }
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 8) {
                        ForEach(vm.messages) { m in
                            Bubble(isUser: m.role == "user", text: m.content)
                                .id(m.id)
                        }
                        if !vm.streaming.isEmpty {
                            Bubble(isUser: false, text: vm.streaming + " ▍")
                                .id("streaming")
                        }
                    }
                    .padding(.horizontal, 12)
                }
                .onChange(of: vm.messages.count) { _ in scroll(proxy) }
                .onChange(of: vm.streaming) { _ in scroll(proxy) }
            }
            HStack {
                TextField("Message \(vm.character.name)...", text: $input, axis: .vertical)
                    .textFieldStyle(.roundedBorder).lineLimit(1...4)
                Button("Send") {
                    vm.send(input); input = ""
                }
                .disabled(vm.generating || input.isEmpty || !LLMEngine.shared.isLoaded)
            }
            .padding(12)
        }
        .navigationTitle(vm.character.name)
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button("Clear") { vm.clearChat() }
            }
            if vm.generating {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Stop") { vm.stop() }
                }
            }
        }
    }

    private func scroll(_ proxy: ScrollViewProxy) {
        withAnimation {
            if let last = vm.messages.last { proxy.scrollTo(last.id, anchor: .bottom) }
            else { proxy.scrollTo("streaming", anchor: .bottom) }
        }
    }
}

struct Bubble: View {
    let isUser: Bool
    let text: String
    var body: some View {
        HStack {
            if isUser { Spacer(minLength: 60) }
            Text(text)
                .padding(12)
                .background(isUser ? Color.accentColor.opacity(0.2) : Color(.secondarySystemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 16))
            if !isUser { Spacer(minLength: 60) }
        }
    }
}
