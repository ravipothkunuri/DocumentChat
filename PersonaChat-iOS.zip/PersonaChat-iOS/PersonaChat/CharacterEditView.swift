import SwiftUI

struct CharacterEditView: View {
    @State var character: Character
    @Environment(\.dismiss) private var dismiss
    @State private var showAiModify = false

    var body: some View {
        Form {
            Section("Basics") {
                TextField("Name", text: $character.name)
                TextField("Avatar emoji", text: $character.avatar)
            }
            Section("Persona (who they are, speech style, background)") {
                TextEditor(text: $character.persona).frame(minHeight: 120)
            }
            Section("Scenario / setting (optional)") {
                TextEditor(text: $character.scenario).frame(minHeight: 70)
            }
            Section("First message (greeting)") {
                TextEditor(text: $character.greeting).frame(minHeight: 70)
            }
            Section("Example dialogue (optional)") {
                TextEditor(text: $character.exampleDialogue).frame(minHeight: 70)
            }
            Section {
                Button("\u{2728} Modify with AI (prompt)") { showAiModify = true }
                Button("Delete character", role: .destructive) {
                    CharacterStore.shared.delete(character.id)
                    dismiss()
                }
            }
        }
        .navigationTitle("Edit \(character.name)")
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button("Save") { CharacterStore.shared.upsert(character); dismiss() }
            }
        }
        .background(
            NavigationLink(destination: AiModifyView(character: character, onApply: { updated in
                character = updated
                CharacterStore.shared.upsert(updated)
            }), isActive: $showAiModify) { EmptyView() }.hidden()
        )
    }
}
