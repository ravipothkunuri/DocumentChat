package com.personachat.ai

import com.personachat.data.Character
import com.personachat.data.ChatMessage

object PromptBuilder {

    fun systemPrompt(c: Character): String = buildString {
        append("You are ${c.name}, a fictional character in a roleplay chat.\n")
        if (c.persona.isNotBlank()) append("Personality and background:\n${c.persona}\n")
        if (c.scenario.isNotBlank()) append("Current scenario/setting:\n${c.scenario}\n")
        if (c.exampleDialogue.isNotBlank()) append("Example dialogue (match this voice):\n${c.exampleDialogue}\n")
        append("\nRules: Always stay fully in character as ${c.name}. Never break character, ")
        append("never mention being an AI or a language model, never describe out-of-character actions. ")
        append("Write as ${c.name} in first person. Keep replies conversational (a few sentences unless the scene calls for more).")
    }

    /**
     * Builds the raw prompt. Prefers the model's built-in chat template;
     * falls back to a plain instruct format if the model has none.
     */
    fun buildPrompt(c: Character, history: List<ChatMessage>): String {
        val pairs = buildList {
            add("system" to systemPrompt(c))
            history.forEach { add(it.role to it.content) }
        }
        val templated = LlmEngine.applyChatTemplate(pairs, addAssistant = true)
        if (templated.isNotBlank()) return templated
        // fallback plain format
        return buildString {
            append("System: ${systemPrompt(c)}\n\n")
            history.forEach { append("${if (it.role == "user") "User" else c.name}: ${it.content}\n\n") }
            append("${c.name}: ")
        }
    }

    /** Trims history so system + recent turns fit roughly in the context budget. */
    fun trimmedHistory(history: List<ChatMessage>, maxChars: Int = 6000): List<ChatMessage> {
        val out = ArrayList<ChatMessage>()
        var used = 0
        for (m in history.asReversed()) {
            if (used + m.content.length > maxChars) break
            out.add(m); used += m.content.length
        }
        return out.asReversed()
    }
}
