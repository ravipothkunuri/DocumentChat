// JNI bridge to llama.cpp for PersonaChat.
// Written against the modern C API (llama_model_load_from_file / sampler chains /
// llama_chat_apply_template). llama.cpp moves fast: if a symbol is renamed in a
// newer checkout, adjust here -- see README "Troubleshooting".
#include <jni.h>
#include <string>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <mutex>
#include <android/log.h>

#include "llama.h"

#define LOG_TAG "persona-jni"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static llama_model   *g_model  = nullptr;
static llama_context *g_ctx    = nullptr;
static const llama_vocab *g_vocab = nullptr;
static int32_t        g_n_ctx  = 4096;
static std::mutex     g_mutex;
static volatile bool  g_stop   = false;

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_personachat_ai_LlmEngine_nativeLoadModel(JNIEnv *env, jobject,
                                                  jstring jpath, jint n_ctx, jint n_threads) {
    std::lock_guard<std::mutex> lock(g_mutex);
    const char *path = env->GetStringUTFChars(jpath, nullptr);

    if (g_ctx)    { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model)  { llama_model_free(g_model); g_model = nullptr; }

    llama_backend_init();

    llama_model_params mparams = llama_model_default_params();
    mparams.n_gpu_layers = 0; // CPU-only by default; raise if you build with GPU support
    g_model = llama_model_load_from_file(path, mparams);
    env->ReleaseStringUTFChars(jpath, path);
    if (!g_model) { LOGE("failed to load model"); return JNI_FALSE; }

    llama_context_params cparams = llama_context_default_params();
    cparams.n_ctx        = (uint32_t) n_ctx;
    cparams.n_threads    = (uint32_t) n_threads;
    cparams.n_threads_batch = (uint32_t) n_threads;
    cparams.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_ENABLED;

    g_ctx = llama_init_from_model(g_model, cparams);
    if (!g_ctx) { llama_model_free(g_model); g_model = nullptr; return JNI_FALSE; }

    g_vocab = llama_model_get_vocab(g_model);
    g_n_ctx = (int32_t) n_ctx;
    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_personachat_ai_LlmEngine_nativeFree(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx)   { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}

JNIEXPORT void JNICALL
Java_com_personachat_ai_LlmEngine_nativeStop(JNIEnv *, jobject) {
    g_stop = true;
}

// Streaming generation. Runs on the caller's thread (use a background thread in Kotlin).
JNIEXPORT jstring JNICALL
Java_com_personachat_ai_LlmEngine_nativeGenerate(JNIEnv *env, jobject,
        jstring jprompt, jfloat temp, jfloat top_p, jint n_predict, jlong seed,
        jobject jcallback) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_ctx || !g_model) return env->NewStringUTF("");

    g_stop = false;
    const char *prompt = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt_str(prompt);
    env->ReleaseStringUTFChars(jprompt, prompt);

    // tokenize (with BOS)
    const int n_max = g_n_ctx - 8;
    std::vector<llama_token> tokens(n_max + 8);
    int n_prompt = llama_tokenize(g_vocab, prompt_str.c_str(), (int32_t) prompt_str.size(),
                                  tokens.data(), tokens.size(), true, true);
    if (n_prompt < 0) return env->NewStringUTF("");
    if (n_prompt > n_max) {
        // keep the tail of the prompt if it doesn't fit
        tokens.erase(tokens.begin(), tokens.begin() + (n_prompt - n_max));
        n_prompt = n_max;
    }

    jclass cb_cls = env->GetObjectClass(jcallback);
    jmethodID cb_mid = env->GetMethodID(cb_cls, "onToken", "(Ljava/lang/String;)V");

    llama_batch batch = llama_batch_get_one(tokens.data(), n_prompt);
    if (llama_decode(g_ctx, batch) != 0) return env->NewStringUTF("");

    llama_sampler *sp = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(sp, llama_sampler_init_top_p(top_p, 1));
    llama_sampler_chain_add(sp, llama_sampler_init_temp(temp <= 0.0f ? 0.05f : temp));
    llama_sampler_chain_add(sp, llama_sampler_init_dist((uint32_t) (seed < 0 ? std::rand() : seed)));

    std::string out;
    const int n_keep = 256; // rolling window if context fills mid-generation
    for (int i = 0; i < n_predict && !g_stop; i++) {
        llama_token tok = llama_sampler_sample(sp, g_ctx, -1);
        if (llama_vocab_is_eog(g_vocab, tok)) break;

        char buf[256];
        int n = llama_token_to_piece(g_vocab, tok, buf, sizeof(buf), 0, true);
        if (n > 0) {
            std::string piece(buf, n);
            out += piece;
            jstring jpiece = env->NewStringUTF(piece.c_str());
            env->CallVoidMethod(jcallback, cb_mid, jpiece);
            env->DeleteLocalRef(jpiece);
        }

        batch = llama_batch_get_one(&tok, 1);
        if (llama_decode(g_ctx, batch) != 0) break;

        // naive context shift: drop oldest tokens when full
        if (llama_get_kv_cache_used_cells(g_ctx) >= (uint32_t)(g_n_ctx - 4)) {
            llama_kv_cache_seq_rm(g_ctx, 0, 1, n_keep);
            llama_kv_cache_seq_add(g_ctx, 0, n_keep, -1, -1);
        }
    }

    llama_sampler_free(sp);
    return env->NewStringUTF(out.c_str());
}

// Apply the model's built-in chat template (llama_chat_apply_template, tmpl=nullptr).
// Returns empty string if the model has no template -- caller falls back to a plain format.
JNIEXPORT jstring JNICALL
Java_com_personachat_ai_LlmEngine_nativeApplyTemplate(JNIEnv *env, jobject,
        jobjectArray roles, jobjectArray contents, jboolean add_assistant) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model) return env->NewStringUTF("");

    jsize n = env->GetArrayLength(roles);
    std::vector<llama_chat_message> msgs((size_t) n);
    std::vector<std::string> role_store((size_t) n), content_store((size_t) n);
    for (jsize i = 0; i < n; i++) {
        jstring r = (jstring) env->GetObjectArrayElement(roles, i);
        jstring c = (jstring) env->GetObjectArrayElement(contents, i);
        const char *rs = env->GetStringUTFChars(r, nullptr);
        const char *cs = env->GetStringUTFChars(c, nullptr);
        role_store[i]    = rs;
        content_store[i] = cs;
        msgs[i].role    = role_store[i].c_str();
        msgs[i].content = content_store[i].c_str();
        env->ReleaseStringUTFChars(r, rs);
        env->ReleaseStringUTFChars(c, cs);
        env->DeleteLocalRef(r);
        env->DeleteLocalRef(c);
    }

    // fetch the model's built-in chat template from metadata
    char tmpl[8192];
    int n_tmpl = llama_model_meta_val_str(g_model, "tokenizer.chat_template", tmpl, sizeof(tmpl));
    const char *tmpl_ptr = (n_tmpl > 0) ? tmpl : nullptr;
    if (!tmpl_ptr) return env->NewStringUTF(""); // no template -> Kotlin falls back to plain format

    int needed = llama_chat_apply_template(tmpl_ptr, msgs.data(), (size_t) n,
                                           add_assistant == JNI_TRUE, nullptr, 0);
    if (needed <= 0) return env->NewStringUTF("");
    std::vector<char> buf((size_t) needed + 8);
    llama_chat_apply_template(tmpl_ptr, msgs.data(), (size_t) n,
                              add_assistant == JNI_TRUE, buf.data(), buf.size());
    return env->NewStringUTF(buf.data());
}

} // extern "C"
