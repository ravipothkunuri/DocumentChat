# PersonaChat iOS — offline character chat (llama.cpp)

SwiftUI twin of the Android app: create characters, chat with streaming replies,
rewrite character cards with a plain-English prompt — all on-device. No accounts,
no server, no filtering layer added by the app; behavior is whatever GGUF model
you load.

## Build
1. macOS + Xcode 15+, then install XcodeGen: `brew install xcodegen`
2. `./scripts/fetch_llama_cpp.sh`   (clones llama.cpp into Packages/, it ships Package.swift)
3. `xcodegen generate`              (creates PersonaChat.xcodeproj from project.yml)
4. `open PersonaChat.xcodeproj`, pick your team/signing, run on a real device
   (ARM64 simulator works for UI; inference is slow but functional).

## Getting a GGUF
Same rules as Android: single-file .gguf, 1-4B params, Q4_K_M default.
Files live in the app's Documents directory (Models tab shows them).

**Easiest path:** the Models tab has a **Browse Hugging Face (GGUF)** search box — it
queries the public Hugging Face Hub API (no key needed), sorts by downloads, and tapping
a repo lists its loadable `.gguf` files (split shards filtered out) with sizes; tap **Get**
to download. A manual "download by URL" field is there as a fallback, and you can also drop
a file into the app's Documents via the Files app / Xcode Devices window.

Example (~1.3GB): https://huggingface.co/bartowski/Qwen_Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q4_K_M.gguf

Downloaded models are excluded from iCloud backup.

## Notes
- CPU-only by default (`n_gpu_layers = 0` in LLMEngine.swift). Metal offload requires
  building llama.cpp with Metal enabled in its Package.swift.
- llama.cpp renames C API symbols occasionally; if the build breaks on one, fix it in
  LLMEngine.swift only.
- If XcodeGen fails on the SPM product, open Packages/llama.cpp/Package.swift and use
  the exact library product name listed there in project.yml.
