package com.personachat.ai

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Minimal Hugging Face Hub API client (no API key required).
 * https://huggingface.co/docs/hub/api
 */
object HuggingFaceApi {

    data class Repo(val id: String, val downloads: Long, val likes: Int)
    data class File(val path: String, val size: Long, val url: String)

    private fun get(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 20000
        conn.setRequestProperty("User-Agent", "PersonaChat/1.0")
        if (conn.responseCode !in 200..299) throw java.io.IOException("HTTP " + conn.responseCode)
        return conn.inputStream.bufferedReader().use { it.readText() }
    }

    /** Search GGUF-capable repos on the Hub, most downloaded first. */
    fun search(query: String, limit: Int = 25): List<Repo> {
        val q = URLEncoder.encode(query, "UTF-8")
        val url = "https://huggingface.co/api/models?search=" + q +
                "&limit=" + limit + "&filter=gguf&sort=downloads&direction=-1"
        val arr = JSONArray(get(url))
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Repo(id = o.optString("id"), downloads = o.optLong("downloads"), likes = o.optInt("likes"))
        }
    }

    /** GGUF files in a repo's main branch; split shards (00001-of-...) are excluded. */
    fun ggufFiles(repoId: String): List<File> {
        val url = "https://huggingface.co/api/models/" + repoId + "/tree/main"
        val arr = JSONArray(get(url))
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val path = o.optString("path")
            if (!path.endsWith(".gguf") || path.contains("-of-")) null
            else {
                val encoded = URLEncoder.encode(path, "UTF-8")
                File(path, o.optLong("size"),
                    "https://huggingface.co/" + repoId + "/resolve/main/" + encoded)
            }
        }
    }
}
