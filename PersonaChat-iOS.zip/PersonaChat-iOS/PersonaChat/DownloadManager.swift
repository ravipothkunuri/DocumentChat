import Foundation

enum DownloadManager {
    /// Streams a remote file to disk with progress. Follows redirects (HF resolve URLs).
    static func download(url: URL, dest: URL, onProgress: @escaping @Sendable (Int64, Int64?) -> Void) async throws {
        let (bytes, response) = try await URLSession.shared.bytes(for: URLRequest(url: url))
        let total = (response as? HTTPURLResponse)?.expectedContentLength
        ModelFiles.excludeFromBackup(dest)
        FileManager.default.createFile(atPath: dest.path, contents: nil)
        let handle = try FileHandle(forWritingTo: dest)
        defer { try? handle.close() }
        var done: Int64 = 0
        for try await byte in bytes {
            try handle.write(contentsOf: Data([byte]))
            done += 1
            onProgress(done, total)
        }
    }
}
