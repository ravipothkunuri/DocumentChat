package com.personachat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.personachat.data.Repositories
import com.personachat.ui.AiModifyScreen
import com.personachat.ui.CharacterEditScreen
import com.personachat.ui.CharactersScreen
import com.personachat.ui.ChatScreen
import com.personachat.ui.ModelScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repositories.init(this)
        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    val nav = rememberNavController()
                    NavHost(navController = nav, startDestination = "characters") {
                        composable("characters") {
                            CharactersScreen(
                                onOpenModel = { nav.navigate("models") },
                                onOpenChat = { id -> nav.navigate("chat/$id") },
                                onCreate = { id -> nav.navigate("edit/$id") }
                            )
                        }
                        composable("models") { ModelScreen(onBack = { nav.popBackStack() }) }
                        composable(
                            "edit/{charId}",
                            arguments = listOf(navArgument("charId") { type = NavType.StringType })
                        ) { back ->
                            val id = back.arguments?.getString("charId")!!
                            CharacterEditScreen(
                                charId = id,
                                onBack = { nav.popBackStack() },
                                onChat = { nav.navigate("chat/$id") },
                                onAiModify = { nav.navigate("aimodify/$id") }
                            )
                        }
                        composable(
                            "chat/{charId}",
                            arguments = listOf(navArgument("charId") { type = NavType.StringType })
                        ) { back ->
                            val id = back.arguments?.getString("charId")!!
                            ChatScreen(charId = id, onBack = { nav.popBackStack() })
                        }
                        composable(
                            "aimodify/{charId}",
                            arguments = listOf(navArgument("charId") { type = NavType.StringType })
                        ) { back ->
                            val id = back.arguments?.getString("charId")!!
                            AiModifyScreen(charId = id, onBack = { nav.popBackStack() })
                        }
                    }
                }
            }
        }
    }
}
