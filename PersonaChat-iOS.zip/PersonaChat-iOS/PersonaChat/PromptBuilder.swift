import Foundation

enum PromptBuilder {
    static func systemPrompt(_ c: Character) -> String {
        var s = "You are \(c.name), a fictional character in a roleplay chat.\n"
        if !c.persona.isEmpty { s += "Personality and background:\n\(c.persona)\n" }
        if !c.scenario.isEmpty { s += "Current scenario/setting:\n\(c.scenario)\n" }
        if !c.exampleDialogue.isEmpty { s += "Example dialogue (match this voice):\n\(c.exampleDialogue)\n" }
        s += "\nRules: Always stay fully in character as \(c.name). Never break character, "
        s += "never mention being an AI or a language model. Write as \(c.name) in first person. "
        s += "Keep replies conversational (a few sentences unless the scene calls for more)."
        return s
    }

    /// Model template when available, plain-format fallback otherwise.
    static func buildPrompt(c: Character, history: [ChatMessage]) -> String {
        var msgs: [(role: String, content: String)] = [("system", systemPrompt(c))]
        msgs.append(contentsOf: history.map { ($0.role, $0.content) })
        let templated = LLMEngine.shared.applyChatTemplate(msgs, addAssistant: true)
        if !templated.isEmpty { return templated }
        var s = "System: \(systemPrompt(c))\n\n"
        for m in history { s += "\(m.role == "user" ? "User" : c.name): \(m.content)\n\n" }
        s += "\(c.name): "
        return s
    }

    static func trimmed(_ history: [ChatMessage], maxChars: Int = 6000) -> [ChatMessage] {
        var out: [ChatMessage] = []
        var used = 0
        for m in history.reversed() {
            if used + m.content.count > maxChars { break }
            out.append(m); used += m.content.count
        }
        return out.reversed()
    }
}
