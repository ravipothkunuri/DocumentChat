import Foundation

/// Minimal Hugging Face Hub API client (no API key required).
/// https://huggingface.co/docs/hub/api
enum HFApi {
    struct Repo: Identifiable, Decodable {
        let id: String
        let downloads: Int?
        let likes: Int?
        var displayName: String { id.components(separatedBy: "/").last ?? id }
    }
    private struct TreeNode: Decodable { let path: String; let size: Int64? }

    static func search(_ query: String, limit: Int = 25) async throws -> [Repo] {
        var comp = URLComponents(string: "https://huggingface.co/api/models")!
        comp.queryItems = [
            .init(name: "search", value: query),
            .init(name: "limit", value: "\(limit)"),
            .init(name: "filter", value: "gguf"),
            .init(name: "sort", value: "downloads"),
            .init(name: "direction", value: "-1")
        ]
        let (data, resp) = try await URLSession.shared.data(from: comp.url!)
        guard (resp as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
        return try JSONDecoder().decode([Repo].self, from: data)
    }

    /// GGUF files in a repo's main branch; split shards (00001-of-...) excluded.
    static func ggufFiles(_ repoId: String) async throws -> [(path: String, size: Int64, url: URL)] {
        let u = URL(string: "https://huggingface.co/api/models/\(repoId)/tree/main")!
        let (data, resp) = try await URLSession.shared.data(from: u)
        guard (resp as? HTTPURLResponse)?.statusCode == 200 else { throw URLError(.badServerResponse) }
        let nodes = try JSONDecoder().decode([TreeNode].self, from: data)
        return nodes.filter { $0.path.hasSuffix(".gguf") && !$0.path.contains("-of-") }
            .map { n in
                let enc = n.path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? n.path
                return (n.path, n.size ?? 0,
                        URL(string: "https://huggingface.co/\(repoId)/resolve/main/\(enc)")!)
            }
    }
}
