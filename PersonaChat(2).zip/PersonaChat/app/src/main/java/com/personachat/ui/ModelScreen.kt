package com.personachat.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.personachat.ai.Downloader
import com.personachat.ai.HuggingFaceApi
import com.personachat.ai.LlmEngine
import com.personachat.data.Repositories
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var models by remember { mutableStateOf(Repositories.listModels()) }
    var status by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var progress by remember { mutableStateOf<Float?>(null) }
    var ctxSize by remember { mutableStateOf(4096f) }

    // ---- Hugging Face browser state ----
    var query by remember { mutableStateOf("") }
    var repos by remember { mutableStateOf<List<HuggingFaceApi.Repo>>(emptyList()) }
    var files by remember { mutableStateOf<List<HuggingFaceApi.File>>(emptyList()) }
    var selectedRepo by remember { mutableStateOf<String?>(null) }
    var searching by remember { mutableStateOf(false) }

    fun refresh() { models = Repositories.listModels() }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Local model") },
            navigationIcon = { TextButton(onBack) { Text("Back") } })
    }) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).padding(horizontal = 16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            item {
                OutlinedTextField(url, { url = it }, label = { Text("GGUF download URL") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Button(enabled = progress == null && url.isNotBlank(), onClick = {
                        scope.launch {
                            try {
                                status = "Downloading..."
                                val dest = Repositories.newDownloadFile(url)
                                Downloader.download(url, dest) { done, total ->
                                    progress = if (total > 0) done.toFloat() / total else null
                                    status = "Downloading %.1f MB".format(done / 1e6)
                                }
                                status = "Saved: ${dest.name}"
                                refresh()
                            } catch (t: Throwable) { status = "Download failed: ${t.message}" }
                            progress = null
                        }
                    }) { Text("Download") }
                    if (progress != null) progress?.let { CircularProgressIndicator(progress = it) }
                }
            }

            // ---- Hugging Face model browser ----
            item {
                HorizontalDivider()
                Text("Browse Hugging Face (GGUF)", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(query, { query = it; selectedRepo = null; files = emptyList() },
                        label = { Text("Search models, e.g. qwen3, llama-3.2") },
                        modifier = Modifier.weight(1f), singleLine = true)
                    Button(enabled = !searching && query.isNotBlank(), onClick = {
                        scope.launch {
                            searching = true; status = "Searching..."
                            try { repos = HuggingFaceApi.search(query) }
                            catch (t: Throwable) { repos = emptyList(); status = "Search failed: ${t.message}" }
                            searching = false
                            if (status.startsWith("Searching")) status = "${repos.size} results"
                        }
                    }) { Text(if (searching) "..." else "Search") }
                }
            }

            items(repos, key = { it.id }) { r ->
                ElevatedCard(Modifier.fillMaxWidth().clickable {
                    selectedRepo = r.id
                    scope.launch {
                        status = "Listing files for ${r.id}..."
                        try { files = HuggingFaceApi.ggufFiles(r.id) }
                        catch (t: Throwable) { files = emptyList(); status = "Failed: ${t.message}" }
                        if (files.isEmpty()) status = "${r.id}: no loadable .gguf files found"
                    }
                }) {
                    Row(Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(r.id.substringAfter('/'), style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f))
                        Text("${"%,d".format(r.downloads)} dl · ${r.likes} likes",
                            style = MaterialTheme.typography.bodySmall)
                    }
                    if (selectedRepo == r.id) {
                        files.forEach { f ->
                            Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(f.path.substringAfterLast('/'),
                                        style = MaterialTheme.typography.bodyMedium)
                                    Text("%.2f GB".format(f.size / 1e9),
                                        style = MaterialTheme.typography.bodySmall)
                                }
                                Button(onClick = {
                                    scope.launch {
                                        try {
                                            status = "Downloading ${f.path.substringAfterLast('/')}..."
                                            val dest = Repositories.newDownloadFile(f.url)
                                            Downloader.download(f.url, dest) { done, total ->
                                                progress = if (total > 0) done.toFloat() / total else null
                                                status = "Downloading %.1f MB".format(done / 1e6)
                                            }
                                            status = "Saved: ${dest.name}"; refresh()
                                        } catch (t: Throwable) { status = "Download failed: ${t.message}" }
                                        progress = null
                                    }
                                }, enabled = progress == null) { Text("Get") }
                            }
                        }
                    }
                }
            }

            item {
                HorizontalDivider()
                Text("Context size: ${ctxSize.toInt()} tokens", style = MaterialTheme.typography.labelLarge)
                Slider(ctxSize, { ctxSize = it }, valueRange = 2048f..16384f, steps = 6)
                Text(status, style = MaterialTheme.typography.bodyMedium)
                if (LlmEngine.isLoaded)
                    Text("Model loaded ✓", color = MaterialTheme.colorScheme.primary)
            }

            items(models, key = { it.name }) { f ->
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(f.name, style = MaterialTheme.typography.titleMedium)
                            Text("%.1f MB".format(f.length() / 1e6),
                                style = MaterialTheme.typography.bodySmall)
                        }
                        if (LlmEngine.isLoaded) {
                            OutlinedButton(onClick = { LlmEngine.unload(); status = "Unloaded" }) {
                                Text("Unload")
                            }
                        } else {
                            Button(onClick = {
                                scope.launch {
                                    status = "Loading ${f.name}..."
                                    status = if (LlmEngine.loadModel(f, ctxSize.toInt()))
                                        "Loaded ${f.name}" else "Failed to load model"
                                }
                            }) { Text("Load") }
                        }
                    }
                }
            }

            item { OutlinedButton(onClick = refresh, modifier = Modifier.fillMaxWidth()) { Text("Rescan files") } }
        }
    }
}
