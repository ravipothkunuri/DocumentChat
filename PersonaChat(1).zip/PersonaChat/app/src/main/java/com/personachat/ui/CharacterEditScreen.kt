package com.personachat.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.personachat.data.Repositories

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharacterEditScreen(charId: String, onBack: () -> Unit, onChat: () -> Unit, onAiModify: () -> Unit) {
    val c = remember(charId) { Repositories.byId(charId) } ?: return LaunchedEffect(Unit) { onBack() }

    var name by remember { mutableStateOf(c.name) }
    var avatar by remember { mutableStateOf(c.avatar) }
    var persona by remember { mutableStateOf(c.persona) }
    var scenario by remember { mutableStateOf(c.scenario) }
    var greeting by remember { mutableStateOf(c.greeting) }
    var example by remember { mutableStateOf(c.exampleDialogue) }

    fun save() {
        c.name = name; c.avatar = avatar; c.persona = persona
        c.scenario = scenario; c.greeting = greeting; c.exampleDialogue = example
        Repositories.upsert(c)
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Edit character") },
            navigationIcon = { TextButton(onBack) { Text("Back") } },
            actions = {
                TextButton(onClick = { save(); onChat() }) { Text("Save & Chat") }
                TextButton(onClick = { save() }) { Text("Save") }
            })
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState())
            .fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {

        OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(avatar, { avatar = it.take(4) }, label = { Text("Avatar emoji") })

        OutlinedTextField(persona, { persona = it },
            label = { Text("Persona (who they are, speech style, background)") },
            modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp), maxLines = 12)

        OutlinedTextField(scenario, { scenario = it },
            label = { Text("Scenario / setting (optional)") },
            modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp), maxLines = 8)

        OutlinedTextField(greeting, { greeting = it },
            label = { Text("First message (greeting)") },
            modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp), maxLines = 8)

        OutlinedTextField(example, { example = it },
            label = { Text("Example dialogue (optional)") },
            modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp), maxLines = 8)

        Button(onClick = { save(); onAiModify() }, modifier = Modifier.fillMaxWidth()) {
            Text("\u2728 Modify with AI (prompt)")
        }

        OutlinedButton(onClick = { Repositories.delete(charId); onBack() },
            modifier = Modifier.fillMaxWidth()) { Text("Delete character") }
        }
    }
}
