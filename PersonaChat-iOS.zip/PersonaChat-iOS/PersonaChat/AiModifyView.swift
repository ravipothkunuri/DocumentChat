import SwiftUI

struct AiModifyView: View {
    let character: Character
    var onApply: (Character) -> Void
    @Environment(\.dismiss) private var dismiss

    @State private var instruction = ""
    @State private var raw = ""
    @State private var proposed: Character?
    @State private var busy = false
    @State private var error: String?

    var body: some View {
        Form {
            Section {
                Text("Describe the change in plain words, e.g. \"make her a cynical pirate captain\".")
                    .font(.caption).foregroundStyle(.secondary)
                TextEditor(text: $instruction).frame(minHeight: 90)
                Button(busy ? "Thinking..." : "Generate changes") { run() }
                    .disabled(busy || instruction.isEmpty || !LLMEngine.shared.isLoaded)
                if !LLMEngine.shared.isLoaded {
                    Text("Load a model first (Model tab).").foregroundStyle(.red)
                }
            }
            if !raw.isEmpty {
                Section("Raw output") {
                    Text(raw).font(.caption2).textSelection(.enabled)
                }
            }
            if let p = proposed {
                Section("Proposed changes") {
                    Text("Name: \(p.name)\n\nPersona: \(p.persona)\n\nScenario: \(p.scenario)\n\nGreeting: \(p.greeting)")
                    Button("Apply & save") {
                        onApply(p); dismiss()
                    }
                    Button("Discard", role: .destructive) { proposed = nil }
                }
            }
            if let error {
                Text(error).foregroundStyle(.red)
            }
        }
        .navigationTitle("AI modify")
    }

    private func run() {
        busy = true; error = nil; proposed = nil; raw = ""
        let c = character
        Task.detached(priority: .userInitiated) {
            let result = CharacterModifier.run(c: c, instruction: instruction) { snapshot in
                Task { @MainActor in raw = snapshot }
            }
            await MainActor.run {
                busy = false
                if let result { proposed = result }
                else { error = "Could not parse the model output — try again or rephrase." }
            }
        }
    }
}
