#!/usr/bin/env bash
# Run from the iOS project root. Clones llama.cpp (which ships a Package.swift)
# into Packages/llama.cpp so XcodeGen can wire it in as a local Swift package.
set -e
mkdir -p Packages
git clone --depth 1 https://github.com/ggml-org/llama.cpp Packages/llama.cpp
echo "Done. Open Package.swift inside Packages/llama.cpp if you need to check product names."
