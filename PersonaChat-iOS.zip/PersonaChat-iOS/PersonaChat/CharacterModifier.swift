import Foundation

/// AI card rewrite: meta-prompt -> local model -> <<<JSON>>>...<<<END>>> -> parse.
enum CharacterModifier {
    static func buildPrompt(c: Character, instruction: String) -> String {
        var s = "You edit character cards for a roleplay chat app. Rewrite the card according to the user's instruction.\n"
        s += "Change only what the instruction asks for; keep the rest. Keep every field appropriate and consistent.\n"
        s += "Output ONLY the updated fields, exactly in this format:\n"
        s += "<<<JSON>>>\n"
        s += "{\"name\": \"...\", \"persona\": \"...\", \"scenario\": \"...\", \"greeting\": \"...\", \"exampleDialogue\": \"...\"}\n"
        s += "<<<END>>>\n"
        s += "No commentary before or after the markers.\n\n"
        s += "CURRENT CARD:\n"
        s += "name: \(c.name)\n"
        s += "persona: \(c.persona)\n"
        s += "scenario: \(c.scenario)\n"
        s += "greeting: \(c.greeting)\n"
        s += "exampleDialogue: \(c.exampleDialogue)\n\n"
        s += "INSTRUCTION: \(instruction)\n\n"
        s += "Updated card:"
        return s
    }

    /// Blocking — call from a background thread. Returns updated copy or nil on parse failure.
    static func run(c: Character, instruction: String, onRaw: @escaping (String) -> Void) -> Character? {
        var full = ""
        LLMEngine.shared.generate(prompt: buildPrompt(c: c, instruction: instruction),
                                  temp: 0.4, nPredict: 1400) { piece in
            full += piece
            onRaw(full)
        }
        return parse(c: c, output: full)
    }

    static func parse(c: Character, output: String) -> Character? {
        var block = output
        if let s = block.range(of: "<<<JSON>>>"), let e = block.range(of: "<<<END>>>"), s.upperBound < e.lowerBound {
            block = String(block[s.upperBound..<e.lowerBound])
        }
        guard let data = block.trimmingCharacters(in: .whitespacesAndNewlines).data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
        func str(_ k: String, _ old: String) -> String {
            (obj[k] as? String).flatMap { $0.isEmpty ? nil : $0 } ?? old
        }
        var copy = c
        copy.name = str("name", c.name)
        copy.persona = str("persona", c.persona)
        copy.scenario = str("scenario", c.scenario)
        copy.greeting = str("greeting", c.greeting)
        copy.exampleDialogue = str("exampleDialogue", c.exampleDialogue)
        return copy
    }
}
