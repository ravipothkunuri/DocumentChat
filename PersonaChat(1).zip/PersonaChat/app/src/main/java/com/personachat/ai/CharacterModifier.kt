package com.personachat.ai

import com.personachat.data.Character
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * "Modify character with AI": sends the current card + a plain-English instruction
 * to the local model and asks for an updated card inside <<<JSON>>>...<<<END>>>.
 * Parsed and applied locally -- nothing leaves the device.
 */
object CharacterModifier {

    private val json = Json { ignoreUnknownKeys = true }

    fun buildPrompt(c: Character, instruction: String): String {
        val card = buildString {
            appendLine("name: ${c.name}")
            appendLine("persona: ${c.persona}")
            appendLine("scenario: ${c.scenario}")
            appendLine("greeting: ${c.greeting}")
            appendLine("exampleDialogue: ${c.exampleDialogue}")
        }
        return buildString {
            appendLine("You edit character cards for a roleplay chat app. Rewrite the card according to the user's instruction.")
            appendLine("Change only what the instruction asks for; keep the rest. Keep every field appropriate and consistent.")
            appendLine("Output ONLY the updated fields, exactly in this format:")
            appendLine("<<<JSON>>>")
            appendLine("{\"name\": \"...\", \"persona\": \"...\", \"scenario\": \"...\", \"greeting\": \"...\", \"exampleDialogue\": \"...\"}")
            appendLine("<<<END>>>")
            appendLine("No commentary before or after the markers.")
            appendLine()
            appendLine("CURRENT CARD:")
            appendLine(card.trim())
            appendLine()
            appendLine("INSTRUCTION: $instruction")
            appendLine()
            append("Updated card:")
        }
    }

    /** Runs blocking -- call from a background dispatcher. Returns updated copy, or null on parse failure. */
    fun runBlocking(c: Character, instruction: String, onRaw: (String) -> Unit): Character? {
        val prompt = buildPrompt(c, instruction)
        val full = StringBuilder()
        LlmEngine.generateBlocking(prompt, temp = 0.4f, nPredict = 1400) {
            full.append(it); onRaw(full.toString())
        }
        return parse(c, full.toString())
    }

    fun parse(c: Character, output: String): Character? {
        val start = output.indexOf("<<<JSON>>>")
        val end = output.indexOf("<<<END>>>")
        val block = if (start >= 0 && end > start) output.substring(start + 10, end) else output
        return runCatching {
            val obj = json.parseToJsonElement(block.trim()).jsonObject
            fun str(k: String, old: String): String =
                runCatching { obj[k]?.jsonPrimitive?.content?.takeIf { it.isNotBlank() } }
                    .getOrNull() ?: old
            c.apply {
                name = str("name", name)
                persona = str("persona", persona)
                scenario = str("scenario", scenario)
                greeting = str("greeting", greeting)
                exampleDialogue = str("exampleDialogue", exampleDialogue)
            }
        }.getOrNull()
    }
}
