package com.personachat.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.personachat.ai.LlmEngine
import com.personachat.data.Repositories

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharactersScreen(onOpenModel: () -> Unit, onOpenChat: (String) -> Unit, onCreate: (String) -> Unit) {
    val chars by Repositories.characters.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("PersonaChat") }, actions = {
                TextButton(onOpenModel) {
                    Text(if (LlmEngine.isLoaded) "Model \u2713" else "Load model")
                }
            })
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                text = { Text("New character") },
                icon = { Text("+") },
                onClick = { onCreate(Repositories.newCharacter().id) }
            )
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).padding(16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(chars, key = { it.id }) { c ->
                ElevatedCard(Modifier.fillMaxWidth(), onClick = { onOpenChat(c.id) }) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(c.avatar, style = MaterialTheme.typography.headlineMedium)
                        Column {
                            Text(c.name, style = MaterialTheme.typography.titleMedium)
                            Text(c.persona.take(90), style = MaterialTheme.typography.bodySmall,
                                maxLines = 2)
                        }
                    }
                }
            }
        }
    }
}
