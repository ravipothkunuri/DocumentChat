package com.personachat.vm

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personachat.ai.LlmEngine
import com.personachat.ai.PromptBuilder
import com.personachat.data.ChatMessage
import com.personachat.data.Repositories
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ChatViewModel(saved: SavedStateHandle) : ViewModel() {

    val charId: String = checkNotNull(saved["charId"])
    val character = Repositories.byId(charId)

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _streaming = MutableStateFlow<String?>(null)
    val streaming: StateFlow<String?> = _streaming.asStateFlow()

    private val _generating = MutableStateFlow(false)
    val generating: StateFlow<Boolean> = _generating.asStateFlow()

    var temperature = 0.8f

    private var job: Job? = null

    init {
        _messages.value = Repositories.loadMessages(charId)
        if (_messages.value.isEmpty() && !character?.greeting.isNullOrBlank()) {
            val greet = ChatMessage("assistant", character!!.greeting)
            _messages.value = listOf(greet)
            persist()
        }
    }

    fun send(userText: String) {
        if (job?.isActive == true || userText.isBlank() || character == null) return
        if (!LlmEngine.isLoaded) return

        val history = _messages.value + ChatMessage("user", userText)
        _messages.value = history
        persist()

        val prompt = PromptBuilder.buildPrompt(character, PromptBuilder.trimmedHistory(history))
        _generating.value = true
        val acc = StringBuilder()

        job = viewModelScope.launch {
            LlmEngine.generateStream(prompt, temp = temperature, nPredict = 600).collect { piece ->
                acc.append(piece)
                _streaming.value = acc.toString()
            }
            val reply = acc.toString().trim()
            _streaming.value = null
            _generating.value = false
            if (reply.isNotEmpty()) {
                _messages.value = _messages.value + ChatMessage("assistant", reply)
                persist()
            }
        }
    }

    fun stop() { LlmEngine.stop() }

    fun clearChat() {
        stop(); job?.cancel()
        _messages.value = emptyList()
        _streaming.value = null
        _generating.value = false
        persist()
    }

    private fun persist() = Repositories.saveMessages(charId, _messages.value)
}
