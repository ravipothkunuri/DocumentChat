package com.personachat.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.personachat.ai.LlmEngine
import com.personachat.vm.ChatViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(charId: String, onBack: () -> Unit) {
    val vm: ChatViewModel = viewModel()
    val messages by vm.messages.collectAsStateWithLifecycle()
    val streaming by vm.streaming.collectAsStateWithLifecycle()
    val generating by vm.generating.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val name = vm.character?.name ?: "Chat"

    LaunchedEffect(messages.size, streaming?.length) {
        val last = listState.layoutInfo.totalItemsCount
        if (last > 0) listState.animateScrollToItem(last - 1)
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(name) },
            navigationIcon = { TextButton(onBack) { Text("Back") } },
            actions = {
                if (generating) TextButton(onClick = { vm.stop() }) { Text("Stop") }
                TextButton(onClick = { vm.clearChat() }) { Text("Clear") }
            }
        )
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (!LlmEngine.isLoaded) {
                Text("No model loaded — go to 'Load model' first.",
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.error)
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                itemsIndexed(messages, key = { i, m -> m.ts.toString() + m.role + i }) { _, m ->
                    Bubble(m.role == "user", m.content)
                }
                if (streaming != null) item { Bubble(false, streaming!!, streaming = true) }
            }
            Row(Modifier.padding(12.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Message $name...") },
                    maxLines = 4
                )
                Button(
                    enabled = !generating && LlmEngine.isLoaded && input.isNotBlank(),
                    onClick = { vm.send(input); input = "" }
                ) { Text("Send") }
            }
        }
    }
}

@Composable
private fun Bubble(isUser: Boolean, text: String, streaming: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement =
        if (isUser) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (isUser) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.secondaryContainer,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Text(
                text + if (streaming) " ▍" else "",
                modifier = Modifier.padding(12.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}
